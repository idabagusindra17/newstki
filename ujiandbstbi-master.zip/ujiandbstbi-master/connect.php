<?php
$host='localhost';
$user='root';
$pass='';
$database='ujiandbstbi-master';
$conn=mysqli_connect( $host,$user,$pass, $database);
?>
